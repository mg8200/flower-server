module .exports ={
    jwtSecret:"somesecrtekeyforjsonwebtoken"
}